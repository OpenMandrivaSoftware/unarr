/* Precomp.h -- StdAfx
2013-11-12 : Igor Pavlov : Public domain */

#ifndef __7Z_PRECOMP_H
#define __7Z_PRECOMP_H

/* #include "Compiler.h" */
#ifdef _MSC_VER
#pragma warning(disable : 4456) // declaration of * hides previous local declaration
#pragma warning(disable : 4457) // declaration of * hides function parameter
#pragma warning(disable : 4996) // This function or variable may be unsafe
#endif
/* #include "7zTypes.h" */

#endif
